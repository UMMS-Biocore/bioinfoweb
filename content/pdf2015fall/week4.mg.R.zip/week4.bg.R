###
## Set up, how many neutral cities (rCities) and how many michelob cities (mCities)
###
rCities = 200;
mCities = 50;
samplers = 50;

####
## Simulate Data
####
rCity.data = rbinom(n = rCities, size=samplers, prob = 0.5);
mCity.data = rbinom(n = mCities, size=samplers, prob = 0.35);
city.data = as.data.frame(c(rCity.data, mCity.data)) #Concatenate the neutral and michelob cities
city.names = list();
for (i in 1:(rCities+mCities)) {
  city.names[i]=paste("city",i,sep="") # Just naming cities
}
rownames(city.data) = city.names

####
## Plotting data neutral and bimodal
####
pdf("~/Dropbox_UMASS/sequence_analysis_bootcamp_2015/preparation/week4.figs.pdf")
hist(city.data[c(1:rCities),1], breaks=20,probability = F, 
     xlab="# prefering Schilitz", ylab="fraction of cities",col="black", main="",xlim=c(0,50));
lines(dbinom(seq(0,50,by=1),size = 50,prob = 0.5)*(rCities),lwd=2,col="red")

min(city.data[c(1:rCities),1])

hist(city.data[,1], breaks=25,probability = F, xlab="# prefering Schilitz", ylab="fraction of cities",col="black", main="",xlim=c(0,50),ylim=c(0,27))
lines(dbinom(seq(0,50,by=1),size = 50,prob = 0.5)*(rCities+mCities),lwd=2,col="red")
min(city.data)
dev.off();

######
## Mix up data so that it looks more real
######
city.names.rand = sample(rownames(city.data));
city.data.rand = as.data.frame(city.data[city.names.rand,])
rownames(city.data.rand) = city.names.rand


######
## Compute pvalues
######
pval <- function(obs) {
  return (pbinom(obs, samplers, p=0.5, lower.tail=T))
}


city.data.rand= cbind (city.data.rand, apply(city.data.rand, MARGIN = 1, FUN=pval));
colnames(city.data.rand) = c("forSchlitz","pvalue")
write.table(city.data.rand, file = "~/Dropbox_UMASS/sequence_analysis_bootcamp_2015/preparation/toy.table.1.txt",quote = F, sep = "\t")

#####
##
####
alpha = 0.1; #Significance level

#Which pass Bonferroni?
city.data.rand[city.data.rand[,2]<alpha/250, ]

###
## Prepare data for BH
###
city.data.rand.sort = city.data.rand[order(city.data.rand[,2],decreasing = F),]


for (i in c(1:length(city.data.rand.sort$forSchlitz))) {
  city.data.rand.sort[i,3] = alpha*i/(rCities+mCities);
}
colnames(city.data.rand.sort) = c("forSchlitz","pvalue", "i/m*q")
write.table(city.data.rand.sort, file = "~/Dropbox_UMASS/sequence_analysis_bootcamp_2015/preparation/toy.table.txt",quote = F, sep = "\t")
